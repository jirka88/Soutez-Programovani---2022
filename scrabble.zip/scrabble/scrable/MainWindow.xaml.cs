﻿using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using static System.Net.Mime.MediaTypeNames;

namespace scrabble
{

    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    /*
    zadání
    Napište program, který pomůže hráči vyhrát deskovou hru "zjednodušený Scrabble", v které má
    hráč za úkol složit co nejdelší slovo z písmen, která má k dispozici.
    Program:
    1. Umožní hráči vybrat a načíst z disku slovníkový soubor, což je textový soubor, kde na
    každém řádku je jedno české slovo.
    2. Umožní hráči zadat písmena, která má k dispozici.Hráč může zadat 1 až 10 písmen, a ta se i
    můžou opakovat.Na velikosti písmen nezáleží.
    3. Najde v načteném slovníku nejdelší slovo, které lze složit z písmen, která hráč zadal, a hráči
    ho zobrazí.
    Příklad:
    Hráč vybere soubor slovnik.txt, který obsahuje tento text:
    aby
    aféra
    Afrika
    agent
    Hráč dále zadá písmena "aférbyb". Nejdelší slovo, které se z těchto písmen dá složit, je tedy "aby".
    Slovo "aféra" sice také obsahuje jen tato písmena, ale obsahuje písmeno "a" dvakrát, ale mezi
    hráčovými písmeny je "a" jen jednou, tedy delší slovo "aféra" složit nelze
    */
    public partial class MainWindow : Window
    {
        OpenFileDialog fileDialog = new OpenFileDialog();
        string BiggerName = "";
        public MainWindow()
        {
            InitializeComponent();
        }
        private void Load(object sender, RoutedEventArgs e)
        {
            fileDialog.DefaultExt = ".txt";
            fileDialog.Filter = "Text documents (.txt)|*.txt";
            fileDialog.ShowDialog();
            Path.Text = fileDialog.FileName;
        }

        private void Search(object sender, RoutedEventArgs e)
        {
            BiggerName = "";
            string Input = inputChar.Text.ToLower();
            if (fileDialog.FileName == "" || inputChar.Text == "")
            {
                MessageBox.Show("Nezadal jste požadované vstupy!");
                return;
            }      
           
            StreamReader ReadFile = new StreamReader(fileDialog.FileName);
            while (!ReadFile.EndOfStream)
            {
                //Načtení řádku v txt
                char[] LoadedRow = ReadFile.ReadLine().ToLower().ToCharArray();
                //temp uložených znaků ze vstupu
                string Temp = Input;
                //Znak, kde se ukládá shoda
                char symbol;
                int Length = 0;
         
                string BiggerNameTest = "";

                for (int i = 0; i < LoadedRow.Length; i++)
                {               
                    //Najde schodu načteného slova z txt se zadanými znaky ze vstupu
                    symbol = Temp.Where(x => x == LoadedRow[i]).FirstOrDefault();
                    if (symbol.ToString() != "\0")
                    {
                        //vymaže společný symbol ze vstupu 
                        int IndexOfSymbol = Temp.IndexOf(symbol);
                        Temp = Temp.Remove(IndexOfSymbol,1);   
                        Length++;
                        //pokud byly nalezeny všechny znaky u načteného slova z txt 
                        if (Length == LoadedRow.Length)
                        {                    
                            BiggerNameTest = new string(LoadedRow);

                            if (BiggerName.Length < BiggerNameTest.Length)
                            {
                                BiggerName = BiggerNameTest;
                            }
                            break;
                        }
                    }  
                }
            }
            if(BiggerName == "")
            {
                Output.Content = "Žádne shodné slovo nebylo nalezeno";
                return;
            }
            Output.Content = BiggerName;
            ReadFile.Close();
            
        }
    }
}
